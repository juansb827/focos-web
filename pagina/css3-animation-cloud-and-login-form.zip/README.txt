A Pen created at CodePen.io. You can find this one at http://codepen.io/ravinthranath/pen/GggyrP.

 A simple sky with animated clouds moving around. Simple parralax effect achieved using variable speed and opacity for the clouds. Can be used in websites, games, etc. 

we used cloud animation with login form.. developing that for something different and latest one..