A Pen created at CodePen.io. You can find this one at http://codepen.io/DamirZ/pen/dYpoZY.

 Just a basic elegant and fancy login form ^.^

Forked from [Victor Hugo Matias](http://codepen.io/reidark/)'s Pen [Elegant Login Form](http://codepen.io/reidark/pen/uAmey/).

Forked from [Victor Hugo Matias](http://codepen.io/reidark/)'s Pen [Elegant Login Form](http://codepen.io/reidark/pen/uAmey/).