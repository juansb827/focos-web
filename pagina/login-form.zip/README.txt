A Pen created at CodePen.io. You can find this one at http://codepen.io/frytyler/pen/EGdtg.

 I built this login form to block the front end of most of my freelance wordpress projects during the development stage. 

This is just the HTML / CSS of it but it uses wordpress's login system. 

Nice and Simple